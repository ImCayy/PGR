﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PGR_Somrova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public enum BWmethod // Definice výčtového typu pro metody převodu na černobílou
        {
            None,
            Average,
            Luminosity,
            Desaturation,
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private BWmethod active = BWmethod.None; // Proměnná pro uchování aktuální vybrané metody B&W
        Bitmap Obrázek;
        Bitmap Obrázek_original;
        private void button1_Click_1(object sender, EventArgs e)
        { // Všechny filtry začánají na nule
            trackBar1.Value = 0;
            trackBar2.Value = 0;
            SliderRed.Value = 0;
            SliderGreen.Value = 0;
            SliderBlue.Value = 0;
            openFileDialog1.Filter = "PNG Image|*.png|JPEG Image|*.jpg|Bitmap Image|*.bmp"; // Filter pro výběr souboru (obrázku) při opendialog
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName); // Načtení obrázku do pictureboxu
                Obrázek_original = new Bitmap(pictureBox1.Image); // Uložení originálního obrázku pro pozdější úpravy
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "PNG Image|*.png|JPEG Image|*.jpg|Bitmap Image|*.bmp"; // Filter pro ukládání upraveného obrázku
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image.Save(saveFileDialog1.FileName); // Uložení obrázku
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private void BW_methods()
        {
            // Dva vnořené cykly, které projíždí obrázek pixel po pixelu
            for (int x = 0; x < Obrázek.Width; x++)
            {
                for (int y = 0; y < Obrázek.Height; y++)
                {
                    Color pixelColor = Obrázek.GetPixel(x, y); // Načtení původní barvy
                    if (BWmethod.Average == active) // Průměrná metoda převodu na černobílou
                    { // Funguje pomocí aritmetického průměru všech tří barevných složek
                        int grayValue = (pixelColor.R + pixelColor.G + pixelColor.B) / 3;
                        Color grayColor = Color.FromArgb(grayValue, grayValue, grayValue);
                        Obrázek.SetPixel(x, y, grayColor);
                    }
                    else if (BWmethod.Luminosity == active) // Metoda převodu na černobílou založená na vnímání jasu
                    { // Metoda fungující na vnímání lidského oka, které nejvíce vnímá zelenou barvu, proto máme 3 koeficienty
                        // 21% červená, 72% zelená a 7% modrá
                        int grayValue = (int)(pixelColor.R * 0.21 + pixelColor.G * 0.72 + pixelColor.B * 0.07);
                        Color grayColor = Color.FromArgb(grayValue, grayValue, grayValue);
                        Obrázek.SetPixel(x, y, grayColor);
                    }
                    else if (BWmethod.Desaturation == active) // Metoda převodu na černobílou založená na saturaci
                    { // Metoda funguje na algoritmu, který najde v píxelu nejméně a nejvíce zastoupenou barvu (Max a Min), tyto dvě hodnoty sečte a vyprůměruje
                        int max = Math.Max(pixelColor.R, Math.Max(pixelColor.G, pixelColor.B));
                        int min = Math.Min(pixelColor.R, Math.Min(pixelColor.G, pixelColor.B));
                        int grayValue = (max + min) / 2;
                        Color grayColor = Color.FromArgb(grayValue, grayValue, grayValue); // Pokud mají R/G/B stejnou hodnotu, výsledkem je odstín šedi
                        Obrázek.SetPixel(x, y, grayColor);
                    }
                }
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex) // Výběr metody černobílého filtru, indexované od nuly
            {
                case 0:
                    active = BWmethod.None; // Původní/originální obrázek
                    break;
                case 1:
                    active = BWmethod.Average;
                    break;
                case 2:
                    active = BWmethod.Luminosity;
                    break;
                case 3:
                    active = BWmethod.Desaturation;
                    break;
            }
            RenderImage();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }
        private void ZmenaJasu()
        {
            for (int x = 0; x < Obrázek.Width; x++)
            {
                for (int y = 0; y < Obrázek.Height; y++)
                {
                    Color pixelColor = Obrázek.GetPixel(x, y); // Počítání nového jasu k hodnotě na slideru
                    int r = Math.Max(0, Math.Min(255, pixelColor.R + trackBar1.Value));
                    int g = Math.Max(0, Math.Min(255, pixelColor.G + trackBar1.Value));
                    int b = Math.Max(0, Math.Min(255, pixelColor.B + trackBar1.Value));
                    Obrázek.SetPixel(x, y, Color.FromArgb(r, g, b));
                } // Pro každý pixel a jeho barevné složce (R/G/B) přičte nebo oděčte hodnotu ze slideru
            }
        }
        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            RenderImage();
        }

        private void ZmenaKontrastu()
        {
            float F = (100.0f + trackBar2.Value) / 100.0f;
            for (int x = 0; x < Obrázek.Width; x++)
            {
                for (int y = 0; y < Obrázek.Height; y++)
                {
                    Color pixelColor = Obrázek.GetPixel(x, y); 
                    // Počítání kontrastu na principu vzdalování a přibližování barev od střední šedé hodnoty (128)
                    // Zjištění vzdálenosti jednotlivé R/G/B složky od střední šedé, vynásobení vzdálenosti koeficientem F (roztáhnutí nebo smrštění), vrácení hodnoty zpět do rozsahu 0-255
                    float r = F * (pixelColor.R - 128) + 128;
                    float g = F * (pixelColor.G - 128) + 128;
                    float b = F * (pixelColor.B - 128) + 128;
                    // Kontrola, zda jsou barvy v rozhraní 0-255, pokud nikoli, automaticky se zarovná na povolené min/max
                    if (r > 255) r = 255; else if (r < 0) r = 0;
                    if (g > 255) g = 255; else if (g < 0) g = 0;
                    if (b > 255) b = 255; else if (b < 0) b = 0;
                    // Složení nových upravených složek, přetypovaných na celá čísla, do nového pixelu
                    Color novyPixel = Color.FromArgb((int)r, (int)g, (int)b);
                    // Zápis do obrázku
                    Obrázek.SetPixel(x, y, novyPixel);
                }
            }
        }
        private void trackBar2_ValueChanged(object sender, EventArgs e)
        {
            RenderImage(); // Render obrázku
        }

        private void Cervena()
        {
            for (int x = 0; x < Obrázek.Width; x++)
            {
                for (int y = 0; y < Obrázek.Height; y++)
                {
                    Color pixelColor = Obrázek.GetPixel(x, y); 
                    // Počítání nové hodnoty pro červenou R barvu
                    // K původní červené se přičte nebo odečte nová hodnota ze slideru, max/min zajistí ořezání (aby barva nebyla mimo rozsah 0-255)
                    // G (Zelená) a B (Modrá) zůstávají stejné, pracujeme pouze s R (Červenou)
                    int r = Math.Max(0, Math.Min(255, pixelColor.R + SliderRed.Value));
                    int g = pixelColor.G;
                    int b = pixelColor.B;
                    // Zápis do obrázku
                    Obrázek.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
        }
        private void SliderRed_ValueChanged(object sender, EventArgs e)
        {
            RenderImage(); // Render obrázku (po změně na červeném slideru)
        }

        private void Zelena()
        {
            for (int x = 0; x < Obrázek.Width; x++)
            {
                for (int y = 0; y < Obrázek.Height; y++)
                {
                    Color pixelColor = Obrázek.GetPixel(x, y);
                    // Počítání nové hodnoty pro zelenou G barvu
                    // K původní zelené se přičte nebo odečte nová hodnota ze slideru, max/min zajistí ořezání (aby barva nebylo mimo rozsah 0-255)
                    // R (Červená) a B (Modrá) zůstávají stejné, pracujeme pouze s G (Zelenou)
                    int r = pixelColor.R;
                    int g = Math.Max(0, Math.Min(255, pixelColor.G + SliderGreen.Value));
                    int b = pixelColor.B;
                    // Zápis do obrázku
                    Obrázek.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
        }
        private void SliderGreen_ValueChanged(object sender, EventArgs e)
        {
            RenderImage(); // Render obrázku (po změně na zeleném slideru)
        }
        private void Modra()
        {
            for (int x = 0; x < Obrázek.Width; x++)
            {
                for (int y = 0; y < Obrázek.Height; y++)
                {
                    Color pixelColor = Obrázek.GetPixel(x, y);
                    // Počítání nové hodnoty pro modrou B barvu
                    // K původní modré se přičte nebo odečte nová hodnota ze slideru, max/min zajistí ořezání (aby barva nebyla mimo rozsah 0-255)
                    // R (Červená) a G (Zelená) zůstávají stejné, pracujeme pouze s B (Modrou)
                    int r = pixelColor.R;
                    int g = pixelColor.G;
                    int b = Math.Max(0, Math.Min(255, pixelColor.B + SliderBlue.Value));
                    // Zápis do obrázku
                    Obrázek.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
        }
        private void SliderBlue_ValueChanged_1(object sender, EventArgs e)
        {
            RenderImage(); // Render obrázku (Po změně na modrém slideru)
        }
        private void RenderImage()
        { // "Hlavní řídící centrum", po každé změně vznikne nový obrázek, na který aplikuje všechny filtry znovu od začátku v přesném pořadí
            if (Obrázek_original != null) // Spustí se jen tehdy, když je nějaký obrázek načtený
            {

                Obrázek = new Bitmap(Obrázek_original); // Nová kopie neupraveného obrázku
                // Aplikace filtrů
                ZmenaJasu(); // Úprava jasu
                ZmenaKontrastu(); // Úprava kontrastu
                Cervena(); // Úprava červeného "nádechu"
                Zelena(); // Úprava zeleného "nádechu"
                Modra(); // Úprava modrého "nádechu"
                BW_methods(); // Aplikace černobílého filtru
                pictureBox1.Image = Obrázek; // Zobrazení výsledku v PictureBoxu
            }
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            
            }
        }
    }

